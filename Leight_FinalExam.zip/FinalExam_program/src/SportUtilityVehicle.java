// creation of suv class
//inherits from vehicle class
public class SportUtilityVehicle extends Vehicle {
    // create variable to store inputs.
    private String _ModelName;
    private int _NumbOfBenchSeats;
    private String _EngineType;

    public SportUtilityVehicle() {}
    // get model name
    public String get_ModelName() {
        return _ModelName;
    }
    // set model name
    public void set_ModelName() {
        this._ModelName = input.nextLine();
    }
    // get number of passengers
    public int get_NumbOfBenchSeats() {
        return _NumbOfBenchSeats;
    }
    // set number of passengers
    public void set_NumbOfBenchSeats() {
        if(input.nextInt() > 6){
            this._NumbOfBenchSeats = input.nextInt();
        }else{
            System.out.println("Please enter a number less than 6");
        }
    }
    // get engine type
    public String get_EngineType() {
        return _EngineType;
    }
    // set engine type
    public void set_EngineType() {
        this._EngineType = input.nextLine();
    }
}
