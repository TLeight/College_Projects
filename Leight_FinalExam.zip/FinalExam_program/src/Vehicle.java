import java.util.Scanner;

// creation of vehicle class
public class Vehicle {
    // create scanner to represent inputs.
    Scanner input = new Scanner(System.in);
    // create variables to store inputs
    private int _Doors;
    private int _Wheels;
    private int _HorsePower;
    private int _NumPassengers;
    private double _Price;
    private String _Manufacturer;
    private int _CrashRating;
    public Vehicle() {}

    // getting doors
    public int get_Doors() {
        return _Doors;
    }
    // setting doors
    public void set_Doors() {
        this._Doors = input.nextInt();
    }
    // getting wheels
    public int get_Wheels() {
        return _Wheels;
    }
    // setting wheels
    public void set_Wheels() {
        this._Wheels = input.nextInt();
    }
    // getting horsepower
    public int get_HorsePower() {
        return _HorsePower;
    }
    // setting horsepower
    public void set_HorsePower() {
        this._HorsePower = input.nextInt();
    }
    // getting number of passengers
    public int get_NumPassengers() {
        return _NumPassengers;
    }
    // setting number of passengers
    public void set_NumPassengers() {
        this._NumPassengers = input.nextInt();
    }
    // get price
    public double get_Price() {
        return _Price;
    }
    // set price
    public void set_Price() {
        this._Price = input.nextDouble();
    }
    // get manufacturer
    public String get_Manufacturer() {
        return _Manufacturer;
    }
    // set manufacturer
    public void set_Manufacturer() {
        this._Manufacturer = input.nextLine();
    }
    // get crash rating
    public int get_CrashRating() {
        return _CrashRating;
    }
    // set crash rating
    public void set_CrashRating() {
        if(input.nextInt() > 5){
            this._CrashRating = input.nextInt();
        }else{
            System.out.println("Please enter a number less than 5");
        }
    }
}
