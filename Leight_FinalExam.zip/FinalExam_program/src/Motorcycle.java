// creation of motorcycle class
//inherits from vehicle class
public class Motorcycle extends Vehicle {
    // create variable to store inputs
    private String _ModelName;
    private boolean _Sidecar;
    private boolean _SignalLights;
    private boolean _Radio;

    public Motorcycle() {}
    // get model name
    public String get_ModelName() {
        return _ModelName;
    }
    // set model name
    public void set_ModelName() {
        this._ModelName = input.nextLine();
    }
    // get sidecar
    public boolean is_Sidecar() {
        return _Sidecar;
    }
    // set side car
    public void set_Sidecar() {
        if(input.nextInt() == 1) {
            this._Sidecar = true;
        }else {
            this._Sidecar = false;
        }
    }
    // get signal lights
    public boolean is_SignalLights() {
        return _SignalLights;
    }
    // set signal lights
    public void set_SignalLights() {
        if(input.nextInt() == 1) {
            this._SignalLights = true;
        }else {
            this._SignalLights = false;
        }
    }
    // get radio
    public boolean is_Radio() {
        return _Radio;
    }
    // set radio
    public void set_Radio() {
        if(input.nextInt() == 1) {
            this._Radio = true;
        }else {
            this._Radio = false;
        }
    }
}
