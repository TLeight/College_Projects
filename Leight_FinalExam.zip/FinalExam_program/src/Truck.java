// creation of truck class
//inherits from vehicle class
public class Truck extends Vehicle {
    //create variable to store inputs
    private String _ModelName;
    private double _CargoCapacity;
    private double _TowingCapacity;
    private boolean _BedLiner;
    private String _Type;

    public Truck() {}
    // get model name
    public String get_ModelName() {
        return _ModelName;
    }
    // set model name
    public void set_ModelName() {
        this._ModelName = input.nextLine();
    }
    // get cargo capacity
    public double get_CargoCapacity() {
        return _CargoCapacity;
    }
    // set cargo capacity
    public void set_CargoCapacity() {
        this._CargoCapacity = input.nextDouble();
    }
    //get towing capacity
    public double get_TowingCapacity() {
        return _TowingCapacity;
    }
    // set towing capacity
    public void set_TowingCapacity() {
        this._TowingCapacity = input.nextDouble();
    }
    // get bed liner
    public boolean is_BedLiner() {
        return _BedLiner;
    }
    // set bed liner
    public void set_BedLiner() {
        if(input.nextInt() == 1) {
            this._BedLiner = true;
        }else {
            this._BedLiner = false;
        }
    }
    //get type
    public String get_Type() {
        return _Type;
    }
    //set type
    public void set_Type() {
        this._Type = input.next();
    }
}
