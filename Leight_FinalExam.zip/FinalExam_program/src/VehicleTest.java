import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
public class VehicleTest {

    Vehicle vehicle;

    public VehicleTest(){}

    @Before
    public void Setup() {this.vehicle = new Vehicle();}

    @Test
    public void GetManufacturerandreturnManufacturer() {
        Assert.assertSame("", this.vehicle.get_Manufacturer());
    }
    @Test
    public void GetPriceandReturnPrice() {
        Assert.assertSame(0.00, this.vehicle.get_Price());
    }
    @Test
    public void GetWheelsandReturnWheels() {
        Assert.assertEquals(0, this.vehicle.get_Wheels());
    }
    @Test
    public void GetDoorsandReturnDoors() {
        Assert.assertEquals(0, this.vehicle.get_Doors());
    }

    @Test
    public void GetHorsePowerandReturnHorsePower() {

        Assert.assertEquals(0, this.vehicle.get_HorsePower());
    }

    @Test
    public void GetPassengersandReturnPassenger() {
        Assert.assertEquals(0L, this.vehicle.get_NumPassengers());
    }

    @Test
    public void GetCrashRatingandReturnCrashRating() {
        Assert.assertEquals(0L,this.vehicle.get_CrashRating());
    }

}
