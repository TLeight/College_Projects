// creation of car class
//inherits from vehicle class
public class Car extends Vehicle {
    // create variable to store inputs
    private String _ModelName;
    private boolean _Convertible;
    private String _EngineType;

    public Car() {}
    // get model name
    public String get_ModelName() {
        return _ModelName;
    }
    // set model name
    public void set_ModelName() {
        this._ModelName = input.nextLine();
    }
    // get convertible
    public boolean is_Convertible() {
        return _Convertible;
    }
    // set convertible
    public void set_Convertible() {
        if(input.nextInt() == 1) {
            this._Convertible = true;
        }else {
            this._Convertible = false;
        }
    }
    // get engine type
    public String get_EngineType() {
        return _EngineType;
    }
    // set engine type
    public void set_EngineType() {
        this._EngineType = input.nextLine();
    }
}
