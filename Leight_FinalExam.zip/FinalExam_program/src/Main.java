import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {

    static Scanner input = new Scanner(System.in);
    public static ArrayList<String> VehicleList = new ArrayList<String>();
    public static void createtruck() {
        getgenralinformation();
        Truck truck = new Truck();
        System.out.println("Model name? ");
        truck.set_ModelName();
        VehicleList.add(truck.get_ModelName());
        System.out.println("Towing capacity? ");
        truck.set_TowingCapacity();
        VehicleList.add(String.valueOf(truck.get_TowingCapacity()));
        System.out.println("Cargo capacity ");
        truck.set_CargoCapacity();
        VehicleList.add(String.valueOf(truck.get_CargoCapacity()));
        System.out.println("Does i have BedLiners ");
        System.out.println("1. yes, 2. no ");
        truck.set_BedLiner();
        VehicleList.add(String.valueOf(truck.is_BedLiner()));
        System.out.println("Truck type? ");
        truck.set_Type();
        VehicleList.add(truck.get_Type());
    }

    public static void createsuv(){
        SportUtilityVehicle suv = new SportUtilityVehicle();
        getgenralinformation();
        System.out.println("Model name? ");
        suv.set_ModelName();
        VehicleList.add(suv.get_ModelName());
        System.out.println("How many benches? ");
        suv.set_NumbOfBenchSeats();
        VehicleList.add(String.valueOf(suv.get_NumbOfBenchSeats()));
        System.out.println("Engine type? ");
        suv.set_EngineType();
        VehicleList.add(suv.get_EngineType());

    }
    public static void createmotorcycle() {
        getgenralinformation();
        Motorcycle motorcycle = new Motorcycle();
        System.out.println("Model name? ");
        motorcycle.set_ModelName();
        VehicleList.add(motorcycle.get_ModelName());
        System.out.println("Side car? ");
        System.out.println("1. yes, 2. no ");
        motorcycle.set_Sidecar();
        VehicleList.add(String.valueOf(motorcycle.is_Sidecar()));
        System.out.println("Signal lights? ");
        System.out.println("1. yes, 2. no ");
        motorcycle.set_SignalLights();
        VehicleList.add(String.valueOf(motorcycle.is_SignalLights()));
        System.out.println("Radio? ");
        System.out.println("1. yes, 2. no ");
        motorcycle.set_Radio();
        VehicleList.add(String.valueOf(motorcycle.is_Radio()));
    }

    public static void createcar() {
        getgenralinformation();
        Car car = new Car();
        System.out.println("Model name? ");
        car.set_ModelName();
        VehicleList.add(car.get_ModelName());
        System.out.println("Convertible? ");
        car.set_Convertible();
        VehicleList.add(String.valueOf(car.is_Convertible()));
        System.out.println("Engine type? ");
        car.set_EngineType();
        VehicleList.add(car.get_EngineType());
    }

    public static void getgenralinformation(){
        Vehicle vehicle = new Vehicle();
        System.out.println("Manufacturer? ");
        vehicle.set_Manufacturer();
        VehicleList.add(vehicle.get_Manufacturer());
        System.out.println("Price? ");
        vehicle.set_Price();
        VehicleList.add(String.valueOf(vehicle.get_Price()));
        System.out.println("Wheels? ");
        vehicle.set_Wheels();
        VehicleList.add(String.valueOf(vehicle.get_Wheels()));
        System.out.println("Doors? ");
        vehicle.set_Doors();
        VehicleList.add(String.valueOf(vehicle.get_Doors()));
        System.out.println("Horse power? ");
        vehicle.set_HorsePower();
        VehicleList.add(String.valueOf(vehicle.get_HorsePower()));
        System.out.println("How many passengers? ");
        vehicle.set_NumPassengers();
        VehicleList.add(String.valueOf(vehicle.get_NumPassengers()));
        System.out.println("Crash rating? ");
        vehicle.set_CrashRating();
        VehicleList.add(String.valueOf(vehicle.get_CrashRating()));
    }
    public static void main(String[] args) {

        System.out.println("Welcome to HFC Vehicle Solutions");
        while (true) {
        System.out.println("1.Create Vehicle, 2.View List, 3.Print List, 4.Exit ");
        int choice = input.nextInt();
        if (choice == 1) {
            System.out.println("Pick a vehicle");
            System.out.println("1.Truck, 2.SUV, 3.Motorcycle, 4. Car");
            choice = input.nextInt();
            if (choice == 1) {
                System.out.println("Please enter the following information about the vehicle. ");
                createtruck();

            } else if (choice == 2) {
                System.out.println("Please enter the following information about the vehicle. ");
                createsuv();
            } else if (choice == 3) {
                System.out.println("Please enter the following information about the vehicle. ");
                createmotorcycle();
            }else {
                System.out.println("Please enter the following information about the vehicle. ");
                createcar();
            }
        }else if (choice == 2) {
            System.out.println(VehicleList.toString());
        }else if (choice == 3) {
            try {
                File file = new File("VehicleCreationList.txt");
                if (file.createNewFile()) {
                    System.out.println("File created: " + file.getName());
                } else {
                    System.out.println("File already exists.");
                }
                FileWriter writer = new FileWriter("VehicleCreationList.txt");
                for(String str: VehicleList) {
                    writer.write(str + ", ");
                }
                writer.close();
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
            return;
        }else {
            System.out.println("thank you come again");
            break;
        }
    }
    }
}