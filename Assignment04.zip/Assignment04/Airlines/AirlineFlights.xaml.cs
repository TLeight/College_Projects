﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;



namespace Airlines
{
    
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> _Arrivals = new List<string>();
        List<string> _Departures = new List<string>();
        string strPlains = "";
        Random randFlightNo = new Random();

        public MainWindow()
        {
            InitializeComponent();

            SetupFlightWindow();

        }

        private void SetupFlightWindow()
        {
            // setup ComboBox control for Flight Type
            cboFlightType.Items.Clear();
            cboFlightType.Items.Add("Arrival");
            cboFlightType.Items.Add("Departure");

            // setup ComboBox control with AM and PM needed for flight time
            cboAmPm.Items.Clear();
            cboAmPm.Items.Add("AM");
            cboAmPm.Items.Add("PM");

            // Set DatePicker control to the current date
            dtpFlightDate.SelectedDate = DateTime.Today;

            
        }

        private void cboFlightType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // If Arrival is selected then the caption label should by "_Arriving from:"
            // otherwise, "_Departing to:"
            if (cboFlightType.SelectedItem.ToString() == "Arrival")
            {
                lblLocationCaption.Content = "Arrivng to";
            }else
            {
                lblLocationCaption.Content = "Departing to";
            }

        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            DateTime Future = dtpFlightDate.DisplayDate;
            DateTime Past = DateTime.Today;
            TimeSpan tmpDaysleft = Future.Subtract(Past);
            int intDaysleft;
            intDaysleft = tmpDaysleft.Days;
            string strDaysleft;
            strDaysleft = intDaysleft.ToString();

            IsValidData();

            if (rdoDelta.IsChecked == true)
            {
                strPlains = "DL";
            }

            if (rdoAirFrance.IsChecked == true)
            {
                strPlains = "FR";
            }

            if (cboFlightType.SelectedItem.ToString() == "Arrival")
            {
                _Arrivals.Add(strPlains + randFlightNo.Next(1000, 10000));
                _Arrivals.Add(dtpFlightDate.DisplayDate.ToShortDateString());
                _Arrivals.Add(txtHour.Text + ':' + txtMinute.Text + cboAmPm.Text);
                _Arrivals.Add(txtGateLetter.Text.ToUpper() + '-' + txtGateNumber.Text);
                _Arrivals.Add(txtCityLocation.Text);
                _Arrivals.Add(strDaysleft);
            }
            
            if (cboFlightType.SelectedItem.ToString() == "Departure")
            {
                _Departures.Add(strPlains + randFlightNo.Next(1000, 10000));
                _Departures.Add(dtpFlightDate.DisplayDate.ToShortDateString());
                _Departures.Add(txtHour.Text + ':' + txtMinute.Text + cboAmPm.Text);
                _Departures.Add(txtGateLetter.Text.ToUpper() + '-' + txtGateNumber.Text);
                _Departures.Add(txtCityLocation.Text);
                _Departures.Add(strDaysleft);
            }
            
        }

        private bool IsValidData()
        {
            bool success = true;
            string ErrMessage = "";

            // Call Validation methods from Validator class to validate input
            ErrMessage += Validator.IsPresent(cboFlightType.Text, "Flight type was not selected");

            ErrMessage += Validator.IsPresent(txtCityLocation.Text, "Input the location of arrival or departing to.");

            ErrMessage += Validator.IsPresent(txtHour.Text, "Input hours");

            ErrMessage += Validator.IsPresent(txtMinute.Text, "Input minutes");

            ErrMessage += Validator.IsPresent(cboAmPm.Text, "Pick a Merridian"); 

            ErrMessage += Validator.IsPresent(txtGateLetter.Text, "Input a gate letter");

            ErrMessage += Validator.IsPresent(txtGateNumber.Text, "Input a gate number");

            ErrMessage += Validator.IsValidFlightTime(txtHour.Text, txtMinute.Text, cboAmPm.ToString());

            ErrMessage += Validator.IsValidFlightDate(dtpFlightDate.DisplayDate);

            ErrMessage += Validator.IsValidFlightGate(txtGateLetter.Text, txtGateNumber.Text);
            // If any errors exist then display in User Messages form
            if (ErrMessage!="")
            {
                success = false;
                User_Messages wndUserMsgs = new User_Messages();
                // display error messages in TextBox control of user messages window
                wndUserMsgs.txtMessages.Text = ErrMessage;

                // Display error messages to user by calling ShowDialog method of user messages window
                wndUserMsgs.ShowDialog();
            }
            return success;

        }

        private void btnDisplayArrivals_Click(object sender, RoutedEventArgs e)
        {
            // Use your List<string> collection for arrivals to display information in the Flight Information window
            Flight_Information frmArrivals = new Flight_Information();

            string[] strArray = _Arrivals.ToArray();

            string strOutput =
                "Flight     Date    Time    Gate\n" +
                strArray[0] + " " + strArray[1] + " " + strArray[2] + " " + strArray[3] + " " + "\nLocation " + strArray[4] + " " +
                "\nThe Flight is in " + strArray[5] + "Days.";

            frmArrivals.txtFlightInformation.Text += string.Join('|', strOutput);

            // Display Flight information to user
            frmArrivals.ShowDialog();
        }

        private void btnDeparture_Click(object sender, RoutedEventArgs e)
        {
            // Use your List<string> collection for departures to display information in the Flight Information window
            Flight_Information frmDepartures = new Flight_Information();

            string[] strArray = _Departures.ToArray();

            string strOutput =
            "Flight     Date    Time    Gate\n" +
            strArray[0] + " " + strArray[1] + " " + strArray[2] + " " + strArray[3] + " " + "\nLocation " + strArray[4] +
            "\nThe Flight is in " + strArray[5] + "Days.";

            frmDepartures.txtFlightInformation.Text += string.Join('|', strOutput);

            // Display Flight information to user
            frmDepartures.ShowDialog();

        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            txtCityLocation.Text = string.Empty;
            txtHour.Text = string.Empty;
            txtMinute.Text = string.Empty;
            txtGateLetter.Text = string.Empty;
            txtGateNumber.Text = string.Empty;
        }
    }
}
