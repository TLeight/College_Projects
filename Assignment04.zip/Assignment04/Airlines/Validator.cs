﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;

namespace Airlines
{
    public static class Validator
        // All methods needed to validate any input will be coded in this
        // static class
    {
        public static string IsValidFlightDate(DateTime FlightDate)
        {
            string msg = "";
            DateTime SixMonthDate;
            DateTime CurrentDate;
            // Make sure FlightDate is not within 6 months of today
            CurrentDate = DateTime.Today;
            SixMonthDate = CurrentDate.AddMonths(+6);
            
            if(FlightDate < SixMonthDate)
            {
                msg += "The flight Date must be six months from today.\n";

            }

            return msg;
        }
        public static string IsValidFlightTime(string Hour, string Minute, string AMPM)
        {
            string msg = "";
            // Make sure Hour is an integer and within 1 to 12 range
            msg += IsInt32(Hour, "Hour");
            msg += IsWithinRange(Hour, "Hour", 1, 12);

            // Make sure minute is an integer and within range of 0 to 59
            msg += IsInt32(Minute, "Minute");
            msg += IsWithinRange(Minute, "Minute", 1, 59);

            // Make sure AMPM is present by calling IsPresent method
            msg += IsPresent(AMPM, "AM/PM");


            return msg;
        }
        public static string IsValidFlightGate(string GateLetter, string GateNo)
        {
            string msg = "";

            // Make sure GateLetter is valid
            GateLetter = GateLetter.ToUpper();
            
            
            // Make sure Gate number is valid based upon gate letter selected
            if (GateLetter.Contains('A'))
            {
                msg += IsInt32(GateNo, "GateNumber");
                msg += IsWithinRange(GateNo, "Gate Number", 1, 78);
            }
            else if (GateLetter.Contains('B'))
            {
                msg += IsInt32(GateNo, "GateNumber");
                msg += IsWithinRange(GateNo, "Gate Number", 1, 21);
            }
            else if (GateLetter.Contains('C'))
            {
                msg += IsInt32(GateNo, "GateNumber");
                msg += IsWithinRange(GateNo, "Gate Number", 1, 43);
            }
            else
            {
                msg += GateLetter + "Must actually be A, B, C. \n";
            }

            return msg;
        }
        public static string IsPresent(string value, string name)
        {
            string msg = "";
            if (value=="")
            {
                msg += name + " is required, it cannot be blank.\n";
            }
            return msg;
        }
        public static string IsInt32(string value, string name)
        {
            string msg = "";
            
            if (!Int32.TryParse(value, out _))
            {
                msg += name + " must be a valid integer value.\n";
            }
            return msg;
        }

        public static string IsWithinRange(string value, string name, decimal min, decimal max)
        {
            string msg = "";
            if (Decimal.TryParse(value, out decimal number))
            {
                if (number < min || number > max)
                {
                    msg += name + " must be between " + min + " and " + max + ".\n";
                }
            }
            return msg;
        }

    }
}
