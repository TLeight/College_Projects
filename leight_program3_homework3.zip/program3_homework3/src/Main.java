import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        myCharacter();
        StatGenerator();
    }
    public static void myCharacter() {

        Scanner Userinput = new Scanner(System.in);

        PlayerCharacter playerCharacter = new PlayerCharacter();

        System.out.println("Welcome to HFC role-play game. ");

        System.out.println("How many characters would you like to create? Between 1 and 10 ");
        int numb = Userinput.nextInt();
        for (int i = 1; i <= numb; i++) {
            System.out.println("Character: " + i);
            playerCharacter.SetStrength();
            playerCharacter.SetDexterity();
            playerCharacter.SetConstitution();
            playerCharacter.SetIntelligence();
            playerCharacter.SetWisdom();
            playerCharacter.SetCharisma();

            System.out.println("Strength: " + playerCharacter.GetStrength() + ", " + "Dexterity: " + playerCharacter.GetDexterity() +
                    ", " + "Constitution: " + playerCharacter.GetConstitution() + ", " + "Intelligence: " + playerCharacter.GetIntelligence() +
                    ". " + "Wisdom: " + playerCharacter.GetWisdom() + ", " + "Charisma: " + playerCharacter.GetCharisma());

            System.out.println("Keep these these stats? 1. Yes, 2. no.");
            int choice = Userinput.nextInt();
            if (choice != 1) {
                playerCharacter.SetStrength();
                playerCharacter.SetDexterity();
                playerCharacter.SetConstitution();
                playerCharacter.SetIntelligence();
                playerCharacter.SetWisdom();
                playerCharacter.SetCharisma();

                System.out.println("Strength: " + playerCharacter.GetStrength() + ", " + "Dexterity: " + playerCharacter.GetDexterity() +
                        ", " + "Constitution: " + playerCharacter.GetConstitution() + ", " + "Intelligence: " + playerCharacter.GetIntelligence() +
                        ". " + "Wisdom: " + playerCharacter.GetWisdom() + ", " + "Charisma: " + playerCharacter.GetCharisma());
            }

            System.out.println("Please enter your name. ");
            playerCharacter.SetCharacterName();

            System.out.println("Please choose a race.");
            System.out.println("1. Dragon-born,2 Dwarf, 3. Elf, 4.Gnome, " +
                    "5. Goblin, 6. Half-ling, 7. Half-Elf, 8. Half-Orc, 9. Human, and 10. Tiefling.");
            playerCharacter.SetCharacterRace();

            System.out.println("Please select a class. ");
            System.out.println("1. Alchemist, 2. Barbarian, 3. Bard, 4. Cleric, 5. Druid, 6. Fighter" +
                    "7. Paladin, 8. Ranger, 9. Rogue, 10. Sorcerer, 11. Witch, 12. Wizard");
            playerCharacter.SetCharacterClass();

            System.out.println("Please pick a gender. ");
            System.out.println("1. Male or 2. Female ");
            playerCharacter.SetCharacterGender();

            System.out.println("Choose Alignment. ");
            System.out.println("1. Lawful Good, 2. Neutral Good, 3. Chaotic Good, 4. Lawful Neutral, " +
                    "5. True Neutral, 6. Chaotic Neutral, 7. Lawful Evil, 8. Neutral Evil, 9. Chaotic Evil");
            playerCharacter.SetCharacterAlignment();

            String[] CharacterArray = new String[6];
            for (int n = 0; n < CharacterArray.length;n++){
                CharacterArray[0] = "Strength: " + playerCharacter.GetStrength() + ", " + "Dexterity: " + playerCharacter.GetDexterity() +
                        ", " + "Constitution: " + playerCharacter.GetConstitution() + ", " + "Intelligence: " + playerCharacter.GetIntelligence() +
                        ". " + "Wisdom: " + playerCharacter.GetWisdom() + ", " + "Charisma: " + playerCharacter.GetCharisma();
                CharacterArray[1] = ("Name: " + playerCharacter.GetName());
                CharacterArray[2] = ("Race: " + playerCharacter.GetRace());
                CharacterArray[3] = ("Class: " + playerCharacter.GetClass());
                CharacterArray[4] = ("Gender: " + playerCharacter.GetGender());
                CharacterArray[5] = ("Alignment: " + playerCharacter.GetAlignment());
                System.out.println(CharacterArray[n]);
            }
        }
        System.out.println("thank you for playing.");
    }
    public static int StatGenerator(){
        Random random = new Random();
        int max = 18, min = 3;
        int number = random.nextInt(max - min + 1);
        return number;
    }
}