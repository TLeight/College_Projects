import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class CharacterTest {

    PlayerCharacter character;

    @Before
    public void setUp(){
            this.character = new PlayerCharacter();
        }

    @Test
    public void GetStrengthandreturnStrength(){
            assertEquals(0, character.GetStrength());

   }

    @Test
    public void GetDexterityandreturnDexterity(){
        assertEquals(0, character.GetDexterity());
    }

    @Test
    public void GetConstitutuionandreturnConstitutuion(){
        assertEquals(0, character.GetConstitution());
    }
    @Test
    public void GetintelligenceandreturnIntelligence(){
        assertEquals(0, character.GetIntelligence());
    }
    @Test
    public void GetWisdomandreturnWisdom(){
        assertEquals(0, character.GetWisdom());
    }
    @Test
    public void GetCharismareturnCharisma(){
        assertEquals(0, character.GetCharisma());
    }

    @Test
    public void GetRandomStatreturnRandomStat() {
        int score = Main.StatGenerator();
        System.out.println("Ability score: " + score);
        assertTrue(score >= 3 && score <= 18);
    }

    @Test
    public void GetStrengthStat() {
        int score = Main.StatGenerator();
        character.SetStrength();
        System.out.println("Strength: " + score);
        assertEquals(score, character.GetStrength());
    }

    @Test
    public void GetDexterityStat() {
        int score = Main.StatGenerator();
        character.SetDexterity();
        System.out.println("Dexterity: " + score);
        assertEquals(score, character.GetDexterity());
    }
    @Test
    public void GetConstitutionStat() {
        int score = Main.StatGenerator();
        character.SetConstitution();
        System.out.println("Constitution: " + score);
        assertEquals(score, character.GetConstitution());
    }

    @Test
    public void GetIntelligenceStat() {
        int score = Main.StatGenerator();
        character.SetIntelligence();
        System.out.println("Intelligence: " + score);
        assertEquals(score, character.GetIntelligence());
    }

    @Test
    public void GetWisdomStat() {
        int score = Main.StatGenerator();
        character.SetWisdom();
        System.out.println("Wisdom: " + score);
        assertEquals(score, character.GetWisdom());
    }

    @Test
    public void GetCharismaStat() {
        int score = Main.StatGenerator();
        character.SetCharisma();
        System.out.println("Charisma: " + score);
        assertEquals(score, character.GetCharisma());
    }

}
