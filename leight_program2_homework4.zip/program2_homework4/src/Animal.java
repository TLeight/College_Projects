import java.util.Scanner;

public class Animal {
    Scanner UserInput = new Scanner(System.in);

    private String _Type;
    private int _Choice;
    private int _Legs;
    public Animal() {}

    public String GetType() {
        return _Type;
    }

    public void SetType() {
        _Choice = UserInput.nextInt();
        if(_Choice == 1) {
            _Type = "Corgi";
        } else if (_Choice == 2) {
            _Type = "German Sheppard";
        } else if (_Choice == 3) {
            _Type = "Labrador";
        } else if (_Choice == 4) {
            _Type = "Exit";
        } else {
            System.out.println("Please enter a valid number");
        }

    }

    public int GetLegs() {
        return _Legs;
    }

    public void SetLegs() {
        this._Legs = UserInput.nextInt();
    }




}
