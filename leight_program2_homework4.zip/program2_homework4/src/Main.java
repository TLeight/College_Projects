import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner UserInput = new Scanner(System.in);

        Dog dog = new Dog();
        Corgi corgi = new Corgi();
        GermanSheppard germanSheppard = new GermanSheppard();
        Labrador labrador = new Labrador();
        Cat cat = new Cat();

        System.out.println("Press 1 for Dog or 2. for cat.");
        int choice = UserInput.nextInt();
        if(choice == 1){
            System.out.println("How many dogs to adopt");
            int many = UserInput.nextInt();
            for (int i = 0; i <= many; i++) {
            System.out.println("Please pick a dog type? 1. corgi, 2. German Sheppard, 3. Labrador , 4. Exit. ");
            dog.SetType();

            System.out.println("How many legs? ");
            dog.SetLegs();

            System.out.println("you chose a " + dog.GetType() + " with "+ dog.GetLegs() + " legs");
            if (dog.GetType() == "Corgi"){
                System.out.println("What is it's name? ");
                corgi.SetName();

                System.out.println("What is it's Age? ");
                corgi.SetAge();

                System.out.println("What is it's Weight? ");
                corgi.SetWeight();

                System.out.println("What is it's Main Color? ");
                corgi.SetColor();

                System.out.println("What is it'sSecondary Color? ");
                corgi.SetSecColor();

                System.out.println("Profile complete");

                System.out.println("Name " + corgi.GetName());

                System.out.println("Age " + corgi.GetAge());

                System.out.println("Weight " + corgi.GetWeight());

                System.out.println("Color " + corgi.GetColor());

                System.out.println("Secondary color " + corgi.GetSecColor());

            } else if (dog.GetType() == "German Sheppard") {
                System.out.println("What is it's name? ");
                germanSheppard.SetName();

                System.out.println("What is it's Age? ");
                germanSheppard.SetAge();

                System.out.println("What is it's Weight? ");
                germanSheppard.SetWeight();

                System.out.println("What is it's Main Color? ");
                germanSheppard.SetColor();

                System.out.println("What is it'sSecondary Color? ");
                germanSheppard.SetSecColor();

                System.out.println("Profile complete");

                System.out.println("Name " + germanSheppard.GetName());

                System.out.println("Age " + germanSheppard.GetAge());

                System.out.println("Weight " + germanSheppard.GetWeight());

                System.out.println("Color " + germanSheppard.GetColor());

                System.out.println("Secondary color " + germanSheppard.GetSecColor());
            } else if (dog.GetType() == "Labrador") {
                System.out.println("What is it's name? ");
                labrador.SetName();

                System.out.println("What is it's Age? ");
                labrador.SetAge();

                System.out.println("What is it's Weight? ");
                labrador.SetWeight();

                System.out.println("What is it's Main Color? ");
                labrador.SetColor();

                System.out.println("What is it'sSecondary Color? ");
                labrador.SetSecColor();

                System.out.println("Profile complete");

                System.out.println("Name " + labrador.GetName());

                System.out.println("Age " + labrador.GetAge());

                System.out.println("Weight " + labrador.GetWeight());

                System.out.println("Color " + labrador.GetColor());

                System.out.println("Secondary color " + labrador.GetSecColor());
            }else if(dog.GetType() == "Exit"){
                    System.out.println("Would you like to continue? 1. no. 2. yes");
                    int numb = UserInput.nextInt();
                    if(numb == 1) {
                        System.out.println("Have a good day. ");
                        break;
                    }else {
                    }
            }
            }
        }else if(choice == 2) {
            System.out.println("How many cats to adopt");
            int many = UserInput.nextInt();
            for (int i = 0; i <= many; i++) {
            System.out.println("What is it's name? ");
            cat.SetName();

            System.out.println("What is it's Age? ");
            cat.SetAge();

            System.out.println("What is it's Weight? ");
            cat.SetWeight();

            System.out.println("What is it's Main Color? ");
            cat.SetColor();

            System.out.println("What is it's Secondary Color? ");
            cat.SetSecColor();

            System.out.println("How many lives used (less than 9) ");
            cat.SetLives();

            System.out.println("Profile complete");

            System.out.println("Name " + cat.GetName());

            System.out.println("Age " + cat.GetAge());

            System.out.println("Weight " + cat.GetWeight());

            System.out.println("Color " + cat.GetColor());

            System.out.println("Secondary color " + cat.GetSecColor());

            System.out.println("Lives used " + cat.GetLives());

            System.out.println("Would you like to continue? 1. no. 2. yes");
            int numb = UserInput.nextInt();
            if(numb == 1) {
                System.out.println("Have a good day. ");
                break;
            }else {
            }
        }
        }
    }
}