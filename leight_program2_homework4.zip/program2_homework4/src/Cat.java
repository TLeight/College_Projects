import java.util.Scanner;

public class Cat extends Animal{
    Scanner UserInput = new Scanner(System.in);
    private String _MainColor;
    private String _SecColor;
    private int _Age;
    private int _Weight;
    private String _Name;
    private int _Lives;
    public Cat() {}
    public String GetColor() {
        return _MainColor;
    }

    public void SetColor() {
        this._MainColor = UserInput.next();
    }

    public String GetSecColor() {
        return _SecColor;
    }

    public void SetSecColor() {
        this._SecColor = UserInput.next();
    }

    public int GetAge() {
        return _Age;
    }

    public void SetAge() {
        this._Age = UserInput.nextInt();
    }

    public int GetWeight() {
        return _Weight;
    }

    public void SetWeight() {
        this._Weight = UserInput.nextInt();
    }

    public String GetName() {
        return _Name;
    }

    public void SetName() {
        this._Name = UserInput.next();
    }

    public int GetLives() {return _Lives;}

    public void SetLives() {this._Lives = UserInput.nextInt();}
}
