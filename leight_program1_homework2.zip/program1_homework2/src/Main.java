// Tyler Leight
// 2-7-23
// cis 171-40
// Richard Morgan
// program runs as a calculator and asks for user
// input to receive a total.

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner UserInput = new Scanner(System.in);



        System.out.println("Welcome to HFC Calculator Program");

        System.out.print("Press 1 for addition or 2 for subtraction: ");
        int choice = UserInput.nextInt();

        if (choice == 1) {
            System.out.print("Please input first value for Addition: ");
            int Firnumb = UserInput.nextInt();

            System.out.print("Please enter the second value to add: ");
            int Secnumb = UserInput.nextInt();

            int Total = Firnumb + Secnumb;
            System.out.println(Firnumb + "+" + Secnumb + "=" + Total);

            System.out.println("Thank You");

        } else if (choice == 2) {
            System.out.print("Please input first value for subtraction: ");
            int Firnumb = UserInput.nextInt();

            System.out.print("Please enter the second value to subtract: ");
            int Secnumb = UserInput.nextInt();

            int Total = Firnumb - Secnumb;
            System.out.println(Firnumb + "-" + Secnumb + "=" + Total);

            System.out.println("Thank You");
        } else {
            System.out.println(choice + " is not a valid number please return and try again.");
            System.out.println("Thank You");
        }
    }
}