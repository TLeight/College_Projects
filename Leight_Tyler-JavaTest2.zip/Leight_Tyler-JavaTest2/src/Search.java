import java.util.Scanner;

public class Search{

    Scanner Userinput = new Scanner(System.in);

    private String _choice;
    private int _input;

    public int Getinput() {
        return _input;
    }

    public void Setinput() {
        _input = Userinput.nextInt();
        if (_input == 1) {
            _choice = "Fantasy";
        } else if (_input == 2) {
            _choice = "Game Guide ";
        } else if (_input == 3) {
            _choice = "Science Fiction";
        }
    }
}
