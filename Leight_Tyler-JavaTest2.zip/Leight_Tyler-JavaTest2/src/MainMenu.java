import java.util.Scanner;

public class MainMenu{
    Scanner Userinput = new Scanner(System.in);

    private String _choice;
    private int _input;

    public int Getinput() {
        return _input;
    }

    public void Setinput() {
        _input = Userinput.nextInt();
        if(_input == 1) {
            _choice = "Search for book";
        } else if (_input == 2) {
            _choice = "Buy Book";
        } else if (_input == 3) {
            _choice = "Display Cart Contents";
        } else if (_input == 4) {
            _choice = "Empty Cart Contents";
        } else if (_input == 5) {
            _choice = "Checkout";
        } else if (_input == 6) {
            _choice = "Exit";
        } else {
            System.out.println("Please enter a valid number");
        }

    }
}
