import java.util.ArrayList;

public class Book {
    private Double _price;
    private String _title;
    private String _category;
    private String _subcategory;
    private String _author;
    private int _invoice;
    private String _isbn;
    private String book1;
    private String book2;
    private String book3;
    private String book4;
    private String book5;
    private String book6;
    private String book7;
    private String book8;

    public Book() {}
    public Book(double _price, String _title, String _category,
                String _subcategory, String _author, int _invoice, String _isbn) {
        this._price = _price;
        this._title = _title;
        this._category = _category;
        this._subcategory = _subcategory;
        this._author = _author;
        this._invoice = _invoice;
        this._isbn = _isbn;
    }
    public String GetBook1() {
        return book1;
    }

    public void SetBook1() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Lord of the Rings");
        book.add("Author J.R.R Tolkien");
        book.add("Price 39.49");
        book.add("Category Fiction");
        book.add("Sub-category Fantasy");
        book.add("ISBN 978-0345538376");
        book.add("Invoice 1");
        this.book1 = book.toString();
    }

    public String GetBook2() {
        return book2;
    }

    public void SetBook2() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title The Expanse Series");
        book.add("Price 114.99");
        book.add("Category Fiction");
        book.add("Sub-categoryScience Fiction");
        book.add("Author James S A Corey");
        book.add("ISBN 978-0678452547");
        book.add("Invoice 2");
        this.book2 = book.toString();
    }
    public String GetBook3() {
        return book3;
    }
    public void SetBook3() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Harry Potter and the Sorcerers Stone");
        book.add("Price 11.34");
        book.add("Category Fiction");
        book.add("Sub-category Fantasy");
        book.add("Author J K. Rowling");
        book.add("ISBN 059035342X");
        book.add("Invoice 3");
        this.book3 = book.toString();
    }

    public String GetBook4(){
        return book4;
    }

    public void SetBook4() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Star Wars: The Thrawn Trilogy.");
        book.add("Price 25.62");
        book.add("Category Fiction");
        book.add("Sub-category Science Fiction");
        book.add("Author Timothy Zahn");
        book.add("ISBN B003H2C53");
        book.add("Invoice 4");
        this.book4 = book.toString();
    }

    public String GetBook5() {
        return book5;
    }

    public void SetBook5() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Dungeons and dragons 5th edition");
        book.add("Price 32.00");
        book.add("Category Fiction");
        book.add("Sub-category Game Manuel");
        book.add("Author various");
        book.add("ISBN 978-0786965601");
        book.add("Invoice 5");
        this.book5 = book.toString();
    }

    public String GetBook6() {
        return book6;
    }
    public void SetBook6() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Pathfinder Second edition rule book");
        book.add("Price 36.11");
        book.add("Category Fiction");
        book.add("Sub-category Game Manuel");
        book.add("Author various");
        book.add("ISBN 978-1640781689");
        book.add("Invoice 6");
        this.book6 = book.toString();
    }

    public String GetBook7() {
        return book7;
    }

    public void SetBook7() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Pathfinder Second edition game masters guide");
        book.add("Price 29.49");
        book.add("Category Fiction");
        book.add("Sub-category Game Manuel");
        book.add("Author various");
        book.add("ISBN 978-1640781986");
        book.add("Invoice 7");
        this.book7 = book.toString();
    }

    public String GetBook8() {
        return book8;
    }
    public void SetBook8() {
        ArrayList<String> book = new ArrayList<String>();
        book.add("Title Star finder core rulebook");
        book.add("Price 33.99");
        book.add("Category Fiction");
        book.add("Sub-category Game Manuel");
        book.add("author various");
        book.add("ISBN 978-160125956");
        book.add("Invoice 8");
        this.book8 = book.toString();
    }
}