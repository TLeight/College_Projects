import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Book book = new Book(0, "", "","", "", 0, "");
        MainMenu menu = new MainMenu();
        Search search = new Search();
        Buybook buybook = new Buybook();
        ArrayList<String> strarray = new ArrayList<String>();
        System.out.println("HFC Book Store.");
        System.out.println("Please select an option. ");
        while (true){
        System.out.println("1. Search for book, 2. Buy book, 3. Display cart, " +
                "4. Empty cart, 5. Checkout, 6. Exit. ");
        menu.Setinput();
        if (menu.Getinput() == 1) {
            System.out.println("Category: Fiction ");
            System.out.print("Please pick a sub category. ");
            System.out.println("1. Fantasy, 2. Game Guide, 3. Science Fiction. ");
            search.Setinput();
            if (search.Getinput() == 1){
                book.SetBook1();
                book.SetBook3();
                System.out.println(book.GetBook1());
                System.out.println(book.GetBook3());
            } else if (search.Getinput() == 2) {
                book.SetBook5();
                book.SetBook6();
                book.SetBook7();
                book.SetBook8();
                System.out.println(book.GetBook5());
                System.out.println(book.GetBook6());
                System.out.println(book.GetBook7());
                System.out.println(book.GetBook8());
            } else if (search.Getinput() == 3) {
                book.SetBook2();
                book.SetBook4();
                System.out.println(book.GetBook2());
                System.out.println(book.GetBook4());
            }
        } else if (menu.Getinput() == 2) {
            System.out.println("Which book would you like to add to cart? ");
            System.out.println("Please enter book number 1-8. ");
            buybook.Setchoice();
            System.out.println("Book added");
        } else if (menu.Getinput() == 3) {
            strarray.add(buybook.Getchoice());
            System.out.println(strarray);
        } else if (menu.Getinput() == 4) {
            strarray.remove(buybook.Getchoice());
            System.out.println("All books where removed. ");
        } else if (menu.Getinput() == 5) {
            buybook.Setprice();
            System.out.println("Total " + buybook.Getprice());
            break;
        }else break;
        }
    }
}