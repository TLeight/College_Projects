import java.util.Scanner;

public class Buybook extends Book{

    Scanner Userinput = new Scanner(System.in);

    private String _choice;
    private int _input;

    private double _price;
    public String Getchoice() {
        return _choice;
    }

    public void Setchoice() {
        _input = Userinput.nextInt();
        if (_input == 1) {
            SetBook1();
            _choice = GetBook1();
        } else if (_input == 2) {
            SetBook2();
            _choice = GetBook2();
        } else if (_input == 3) {
            SetBook3();
            _choice = GetBook3();
        } else if (_input == 4) {
            SetBook4();
            _choice = GetBook4();
        } else if (_input == 5) {
            SetBook5();
            _choice = GetBook5();
        } else if (_input == 6) {
            SetBook6();
            _choice = GetBook6();
        } else if (_input == 7) {
            SetBook7();
            _choice = GetBook7();
        } else if (_input == 8) {
            SetBook8();
            _choice = GetBook8();
        } else {
            System.out.println("Please enter a valid number");
        }
    }

    public double Getprice() {
        return _price;
    }

    public void Setprice() {

        if (_input == 1) {
            this._price = 39.49;
        } else if (_input == 2) {
            this._price = 114.99;
        } else if (_input == 3) {
           this._price = 11.34;
        } else if (_input == 4) {
            this._price = 35.62;
        } else if (_input == 5) {
            this._price = 32.00;
        } else if (_input == 6) {
            this._price = 36.11;
        } else if (_input == 7) {
            this._price = 29.48;
        } else if (_input == 8) {
            this._price = 33.99;
        }
    }
}
