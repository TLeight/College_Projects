public class Labrador extends Dog {
}
