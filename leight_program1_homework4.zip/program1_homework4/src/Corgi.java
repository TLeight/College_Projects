public class Corgi extends Dog {

    public Corgi() {}

}
