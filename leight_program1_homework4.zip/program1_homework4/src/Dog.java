import java.util.Scanner;

public class Dog extends Animal {

    Scanner UserInput = new Scanner(System.in);
    private String _Color;
    private String _SecColor;
    private int _Age;
    private int _Weight;
    private String _Name;
    public Dog() {}
    public String GetColor() {
        return _Color;
    }

        public void SetColor() {
        this._Color = UserInput.nextLine();
    }

    public String GetSecColor() {
        return _SecColor;
    }

    public void SetSecColor() {
        this._SecColor = UserInput.nextLine();
    }

    public int GetAge() {
        return _Age;
    }

    public void SetAge() {
        this._Age = UserInput.nextInt();
    }

    public int GetWeight() {
        return _Weight;
    }

    public void SetWeight() {
        this._Weight = UserInput.nextInt();
    }

    public String GetName() {
        return _Name;
    }

    public void SetName() {
        this._Name = UserInput.nextLine();
    }
}
