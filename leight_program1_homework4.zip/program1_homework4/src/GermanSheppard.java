public class GermanSheppard extends Dog{
}
