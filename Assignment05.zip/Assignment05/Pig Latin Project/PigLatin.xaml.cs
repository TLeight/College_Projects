﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pig_Latin_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // create a list string.
        List<string> lstPiglat = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
           
        }
        
        private void btnConvert_Click(object sender, RoutedEventArgs e)
        {
            // represent the textbox by using a string.
            string strSentence = txtSentence.Text;
            // you will need a constant string to represent the vowels.
            const string strVowels = "AEIOUaeiou";

            // use the for each method.
            // this will search through each charachter of the string for a vowell.
            foreach (string strWords in strSentence.Split(' '))
            {
                // use of substring sre need to validate if the charchter is a vowel.
                string strFirstletter = strWords.Substring(0, 1);
                string strRestofWord = strWords.Substring(1, strWords.Length - 1);
                int intletter = strVowels.IndexOf(strFirstletter);

                // if statement determines if the a vowel is in the first letter of the string..
                if (intletter == -1)
                {
                    lstPiglat.Add(strRestofWord + "-" + strFirstletter + "ay");
                }
                else
                {
                    lstPiglat.Add( strFirstletter + strRestofWord + "-" + "way");
                }
                // display each word on a new line.
                lblPigLatinResults.Content = string.Join("\n", lstPiglat);
            }

        }

        // create clear button.
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lblPigLatinResults.Content = null;
        }
    }
}
