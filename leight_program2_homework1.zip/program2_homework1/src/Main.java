/*
    Tyler Leight

    1-17-2023

    CIS-171

    instructor: Richard Morgan

    Program asks for users first and last name
    program will then ask for the users Age and Birthday.
*/
public class Main {
    public static void main(String[] args) {

        User userInput = new User();

        System.out.print("Please enter your First name: ");
        userInput.SetFirstName("");

        System.out.print("Please enter your Last name: ");
        userInput.SetLastName("");

        System.out.print(("Please enter your BirthDay(Day/Month/Year): "));
        userInput.SetBirthDate("");

        System.out.print(("Please enter your age: "));
        userInput.SetAge(0);



        System.out.println("USER INFORMATION");
        System.out.println("First Name: " + userInput.GetFirstName());
        System.out.println("LastName: " + userInput.GetLastName());
        System.out.println("BirthDate: " + userInput.GetBirthDate() + " " + "Age: " + userInput.GetAge());



    }
}
