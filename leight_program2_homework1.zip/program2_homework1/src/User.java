import java.util.Scanner;

public class User {
    Scanner Userinfo = new Scanner(System.in);

    private String FirstName;
    private String LastName;
    private String BirthDate;
    private int Age;


    public User() {}

    public String GetFirstName() {
        return FirstName;
    }
    public void SetFirstName(String FirstName) {
        this.FirstName = Userinfo.nextLine();
    }

    public String GetLastName() {
        return LastName;
    }
    public void SetLastName(String LastName) {
        this.LastName = Userinfo.nextLine();
    }
    public String GetBirthDate() {
        return BirthDate;
    }

    public void SetBirthDate(String BirthDate) {
        this.BirthDate = Userinfo.next();


    }
    public int GetAge() {
        return Age;
    }

    public void SetAge(int Age) {

        this.Age = Userinfo.nextInt();
    }


}
