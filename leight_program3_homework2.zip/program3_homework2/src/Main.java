import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner UserInput = new Scanner(System.in);

        System.out.println("Welcome to HFC Calculator Program");
        while(true) {
            System.out.print("Press 1 for addition, 2 for subtraction, 3 for multiplication,4 for division, and" +
                    " 5 to calculate the angles of a triangle: ");

            int choice = UserInput.nextInt();

            if (choice == 1) {

                System.out.print("How many values do you wish to add ");
                int val = UserInput.nextInt();
                int total = 0;


                for (int i = 1; i <= val; i++) {

                    System.out.print("Please enter " + i + " value ");
                    int numb = UserInput.nextInt();

                    total += numb;

                }
                System.out.println("Total:" + total);

                System.out.println("Would like to continue 1 for yes 2 for no? ");
                int contnumb = UserInput.nextInt();
                if (contnumb == 1) {
                    continue;
                }
                if (contnumb == 2)
                    System.out.print("Thank you");
                break;

            }else if (choice == 2) {
                System.out.print("How many values do you wish to subtract from 100 ");
                int val = UserInput.nextInt();
                int startnumb = 100;
                int total = 0;

                for (int i = 1; i <= val; i++) {

                    System.out.print("Please enter " + i + " value ");
                    int numb = UserInput.nextInt();

                    total = startnumb -= numb;

                }
                System.out.println("Total: " + total);

                System.out.print("Would like to continue 1 for yes 2 for no? ");
                int contnumb = UserInput.nextInt();
                if (contnumb == 1) {
                    continue;
                }
                if (contnumb == 2)
                    System.out.print("Thank you");
                break;

            } else if(choice == 3) {
                System.out.print("Please input first value for Multiplication: ");
                int Firnumb = UserInput.nextInt();

                System.out.print("Please enter the second value to multiply: ");
                int Secnumb = UserInput.nextInt();

                int total = Firnumb * Secnumb;
                System.out.println("Total: " + total);;

                System.out.print("Would like to continue 1 for yes 2 for no? ");
                int contnumb = UserInput.nextInt();
                if (contnumb == 1) {
                    continue;
                }
                if (contnumb == 2)
                    System.out.print("Thank you");
                break;

            }else if (choice == 4) {
                System.out.print("Please input first value for Division: ");
                int Firnumb = UserInput.nextInt();

                System.out.print("Please enter the second value to dive: ");
                int Secnumb = UserInput.nextInt();

                int total = Firnumb / Secnumb;
                System.out.println("Total: " + total);;

                System.out.print("Would like to continue 1 for yes 2 for no? ");
                int contnumb = UserInput.nextInt();
                if (contnumb == 1) {
                    continue;
                }
                if (contnumb == 2)
                    System.out.print("Thank you");
                break;
            }else if (choice == 5) {

                Calctri inputs = new Calctri();

                System.out.print("Please enter coordinates for angle One");
                inputs.setX1();
                inputs.setY1();

                System.out.print("Please enter coordinates for angle Two");
                inputs.setX2();
                inputs.setY2();

                System.out.print("Please enter coordinates for angle Three");
                inputs.setX3();
                inputs.setX3();

                System.out.println("Angle 1: " + inputs.getAngleOne());

                System.out.println("Angle 2: " + inputs.getAngleTwo());

                System.out.println("Angle 3: " + inputs.getAngleThree());

                System.out.print("Would like to continue 1 for yes 2 for no? ");
                int contnumb = UserInput.nextInt();
                if (contnumb == 1) {
                    continue;
                }
                if (contnumb == 2)
                    System.out.print("Thank you");
                break;

            }else {
                System.out.println(choice + " is not a valid number please return and try again.");

                System.out.println("Thank You");
            }
        }
    }
}
