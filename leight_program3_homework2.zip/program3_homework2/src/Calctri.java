import java.util.Scanner;

import static java.lang.Math.*;

public class Calctri {

    Scanner Angles;

    private double X1;
    private double Y1;
    private double X2;
    private double Y2;
    private double X3;
    private double Y3;

    private double a = Math.pow(X1,Y1);
    private double b = Math.pow(X2,Y2);
    private double c = Math.pow(X3,Y3);

    private double AngleOne;
    private double AngleTwo;
    private double AngleThree;
    public Calctri() {

        this.Angles = new Scanner(System.in);
    }

    public void setX1() {
        X1 = Angles.nextInt();
    }

    public void setY1() {
        Y1 = Angles.nextInt();
    }

    public void setX2() {
        X2 = Angles.nextInt();
    }

    public void setY2() {
        Y2 = Angles.nextInt();
    }

    public void setX3() {
        X3 = Angles.nextInt();
    }

    public void setY3() {
        Y3 = Angles.nextInt();
    }

    public double getAngleOne() {

        return AngleOne = Math.toDegrees(acos((a * a - b * b - c * c) / (-2 * b * c)));
    }

    public double getAngleTwo() {
        return AngleTwo = Math.toDegrees(acos((b * b - a * a - c * c) / (-2 * a * c)));
    }

    public double getAngleThree() {
        return AngleThree = Math.toDegrees(acos((c*c - b*b - a*a) / (-2 * a * b)));
    }
}
