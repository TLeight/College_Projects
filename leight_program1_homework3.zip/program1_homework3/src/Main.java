public class Main {
    public static void main(String[] args) {

        myCharacter();

    }
    public static void myCharacter(){

        Character character = new Character();

        System.out.println("Welcome to HFC role-play game. ");
        System.out.println("Please enter your name. ");
        character.SetCharacterName();

        System.out.println("Please choose a race.");
        System.out.println("1. Dragon-born,2 Dwarf, 3. Elf, 4.Gnome, " +
                "5. Goblin, 6. Half-ling, 7. Half-Elf, 8. Half-Orc, 9. Human, and 10. Tiefling.");
        character.SetCharacterRace();

        System.out.println("Please select a class. ");
        System.out.println("1. Alchemist, 2. Barbarian, 3. Bard, 4. Cleric, 5. Druid, 6. Fighter" +
                "7. Paladin, 8. Ranger, 9. Rogue, 10. Sorcerer, 11. Witch, 12. Wizard");
        character.SetCharacterClass();

        System.out.println("Please pick a gender. ");
        System.out.println("1. Male or 2. Female ");
        character.SetCharacterGender();

        System.out.println("Choose Alignment. ");
        System.out.println("1. Lawful Good, 2. Neutral Good, 3. Chaotic Good, 4. Lawful Neutral, " +
                "5. True Neutral, 6. Chaotic Neutral, 7. Lawful Evil, 8. Neutral Evil, 9. Chaotic Evil");
        character.SetCharacterAlignment();

        System.out.println("Name: " + character.GetName());
        System.out.println("Race: " + character.GetRace());
        System.out.println("Class: " + character.GetClass());
        System.out.println("Gender: " + character.GetGender());
        System.out.println("Alignment: " + character.GetAlignment());
    }
}