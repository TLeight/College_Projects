import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner UserInput = new Scanner(System.in);

        System.out.println("Welcome to HFC Calculator Program");
        while(true) {
        System.out.print("Press 1 for addition or 2 for subtraction: ");

        int choice = UserInput.nextInt();

        if (choice == 1) {

            System.out.print("How many values do you wish to add");
            int val = UserInput.nextInt();
            int total = 0;


                for (int i = 1; i <= val; i++) {

                System.out.print("Please enter " + i + " value ");
                int numb = UserInput.nextInt();

                total += numb;

                }
                System.out.println("Total:" + total);

            System.out.println("Would like to continue 1 for yes 2 for no?");
            int contnumb = UserInput.nextInt();
            if (contnumb == 1) {
                continue;
            }
            if (contnumb == 2)
                System.out.print("Thank you");
            break;

            }else if (choice == 2) {
            System.out.print("How many values do you wish to subtract from 100");
            int val = UserInput.nextInt();
            int startnumb = 100;
            int total = 0;

            for (int i = 1; i <= val; i++) {

                System.out.print("Please enter " + i + " value ");
                int numb = UserInput.nextInt();

                total = startnumb -= numb;

            }
            System.out.println("Total: " + total);

            System.out.print("Would like to continue 1 for yes 2 for no?");
            int contnumb = UserInput.nextInt();
            if (contnumb == 1) {
                continue;
            }
            if (contnumb == 2)
                System.out.print("Thank you");
            break;

        } else {
            System.out.println(choice + " is not a valid number please return and try again.");

            System.out.println("Thank You");
        }
        }
    }
}
