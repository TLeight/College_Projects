﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace Student_List
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        const string StudentDataList = "StudentData.txt";
        List<Student> colStudents = new List<Student>();

        private void btnGetStudents_Click(object sender, RoutedEventArgs e)
        {
            StreamReader inputFile;
            try
            {

                inputFile = File.OpenText(StudentDataList);
                colStudents.Clear();

                string strInput, strStudent;

                while(inputFile.EndOfStream == false)
                {
                    strInput = inputFile.ReadLine();
                    string[] stu = strInput.Split("|");

                    strStudent = stu[0].PadRight(20) + stu[1].PadRight(20) + stu[2].PadRight(20) + 
                        stu[3].PadRight(10) + stu[4].PadRight(10) + stu[5].PadRight(10) + stu[6].PadRight(10);

                   Student student = new Student();
                    student.strID = stu[0];
                    student.strFirstName = stu[1];
                    student.strLastName = stu[2];
                    student.strStreetAdress = stu[3];
                    student.strCity = stu[4];
                    student.strState = stu[5];
                    student.strZipcode = stu[6];
                    
                    colStudents.Add(student);
                    lstStudentsID.Items.Add(student.strID);
                    

                }
                inputFile.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Disk problem");
                return;
            }
        }

        private void lstStudentsID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int intIndex;

            Student studentInfo;

            intIndex = lstStudentsID.SelectedIndex;

            studentInfo = colStudents[intIndex];

            lblFullName.Content = studentInfo.strFirstName + studentInfo.strLastName;

            lblAddress.Content = studentInfo.strStreetAdress + Environment.NewLine + 
                studentInfo.strCity + "," + studentInfo.strState + "  " + studentInfo.strZipcode;
        }
    }
}
