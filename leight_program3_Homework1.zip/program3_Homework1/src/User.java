import java.time.Year;
import java.util.Scanner;

public class User {
    Scanner Userinfo;
    private String FirstName;
    private String LastName;
    private String BirthDate;
    private int Age;

    public User() {

        this.Userinfo = new Scanner(System.in);
    }

    //Getter
    public String GetFirstName() {
        return this.FirstName;
    }

    //Setter
    public void SetFirstName(String FirstName) {

    this.FirstName = this.Userinfo.nextLine();
    }

    //Getter
    public String GetLastName() {

        return this.LastName;
    }

    //Setter
    public void SetLastName(String LastName) {

        this.LastName = this.Userinfo.nextLine();
    }

    //Getter
    public String GetBirthDate() {

        return this.BirthDate;
    }

    //Setter
    public void SetBirthDate(String BirthDate) {

        this.BirthDate = this.Userinfo.nextLine();
    }

    //Getter of Age
    // Setter is not necessary
    public int GetAge() {

        String inputYear = this.BirthDate.substring(this.BirthDate.length() - 4);
        int NumYear = Integer.parseInt(inputYear);

        int CurrentYear = Year.now().getValue();

        return this.Age = CurrentYear - NumYear;
    }


}
