import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

public class Main {
    public static void main(String[] args) {

        Scanner UserInput = new Scanner(System.in);

        Dog dog = new Dog();
        Corgi corgi = new Corgi();
        GermanSheppard germanSheppard = new GermanSheppard();
        Labrador labrador = new Labrador();
        Cat cat = new Cat();

        System.out.println("Press 1 for Dog or 2. for cat.");
        int choice = UserInput.nextInt();
        if(choice == 1){
            System.out.println("How many dogs to adopt");
            int many = UserInput.nextInt();
            for (int i = 1; i <= many; i++) {
            System.out.println("Please pick a dog type? 1. corgi, 2. German Sheppard, 3. Labrador , 4. Exit. ");
            dog.SetType();

            System.out.println("you chose a " + dog.GetType());
            if (dog.GetType() == "Corgi"){
                System.out.println("What is it's name? ");
                corgi.SetName();

                System.out.println("How many legs? ");
                dog.SetLegs();

                System.out.println("What is it's Age? ");
                corgi.SetAge();

                System.out.println("What is it's Weight? ");
                corgi.SetWeight();

                System.out.println("What is it's Main Color? ");
                corgi.SetColor();

                System.out.println("What is it'sSecondary Color? ");
                corgi.SetSecColor();

                System.out.println("Profile complete");

            } else if (dog.GetType() == "German Sheppard") {
                System.out.println("What is it's name? ");
                germanSheppard.SetName();

                System.out.println("What is it's Age? ");
                germanSheppard.SetAge();

                System.out.println("What is it's Weight? ");
                germanSheppard.SetWeight();

                System.out.println("What is it's Main Color? ");
                germanSheppard.SetColor();

                System.out.println("What is it'sSecondary Color? ");
                germanSheppard.SetSecColor();

                System.out.println("Secondary color " + germanSheppard.GetSecColor());
            } else if (dog.GetType() == "Labrador") {
                System.out.println("What is it's name? ");
                labrador.SetName();

                System.out.println("What is it's Age? ");
                labrador.SetAge();

                System.out.println("What is it's Weight? ");
                labrador.SetWeight();

                System.out.println("What is it's Main Color? ");
                labrador.SetColor();

                System.out.println("What is it'sSecondary Color? ");
                labrador.SetSecColor();

            }else if(dog.GetType() == "Exit"){
                    System.out.println("Would you like to continue? 1. no. 2. yes");
                    int numb = UserInput.nextInt();
                    if(numb == 1) {
                        System.out.println("Have a good day. ");
                        break;
                    }else {
                    }
            }
            }
        }else if(choice == 2) {
            System.out.println("How many cats to adopt");
            int many = UserInput.nextInt();
            for (int i = 0; i <= many; i++) {
            System.out.println("What is it's name? ");
            cat.SetName();

            System.out.println("What is it's Age? ");
            cat.SetAge();

            System.out.println("What is it's Weight? ");
            cat.SetWeight();

            System.out.println("What is it's Main Color? ");
            cat.SetColor();

            System.out.println("What is it's Secondary Color? ");
            cat.SetSecColor();

            System.out.println("How many lives used (less than 9) ");
            cat.SetLives();

            System.out.println("Profile complete");

            System.out.println("Would you like to continue? 1. no. 2. yes");
            int numb = UserInput.nextInt();
            if(numb == 1) {
                System.out.println("Have a good day. ");
                break;
            }else {
            }
        }
        }
        try {
            System.out.println("Create a file name. ");
            String filename = UserInput.next();
            File file = new File(filename);
            if (file.createNewFile()) {
                System.out.println("File created: " + filename);
            } else {
                System.out.println("File already exists.");
            }
            PrintWriter writer = new PrintWriter(filename);
            if(dog.GetType() == "Corgi"){
                writer.print("Type " + dog.GetType() +
                        "Name " + corgi.GetName() + " " +
                        "Legs " + dog.GetLegs() + " " +
                        "Age " + corgi.GetAge() + " " +
                        "Weight " + corgi.GetWeight() + " " +
                        "Color " + corgi.GetColor() + " " +
                        "Secondary color " + corgi.GetSecColor());
            } else if (dog.GetType() == "Labrador") {
                writer.print("Type " + dog.GetType() +
                        "Name " + labrador.GetName() + " " +
                        "Legs " + dog.GetLegs() + " " +
                        "Age " + labrador.GetAge() + " " +
                        "Weight " + labrador.GetWeight() + " " +
                        "Color " + labrador.GetColor() + " " +
                        "Secondary color " + labrador.GetSecColor());
            } else if (dog.GetType() == "GermanSheppard") {
                writer.println("Type " + germanSheppard.GetType() +
                        "Name " + germanSheppard.GetName() + " " +
                        "Legs " + dog.GetLegs() + " " +
                        "Age " + germanSheppard.GetAge() + " " +
                        "Weight " + germanSheppard.GetWeight() + " " +
                        "Color " + germanSheppard.GetColor() + " " +
                        "Secondary color " + germanSheppard.GetSecColor());
            } else if (choice == 2) {
                writer.print("Name " + cat.GetName() + " " +
                        "Age " + cat.GetAge() + " " +
                        "Weight " + cat.GetWeight() + " " +
                        "Color " + cat.GetColor() + " " +
                        "Secondary color " + cat.GetSecColor() + " " +
                        "Lives used " + cat.GetLives());
            }
            writer.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}