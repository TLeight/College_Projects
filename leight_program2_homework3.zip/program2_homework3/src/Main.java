import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        myCharacter();
        StatGenerator();
    }
    public static void myCharacter() {

        Scanner Userinput = new Scanner(System.in);

        Character character = new Character();

        System.out.println("Welcome to HFC role-play game. ");

        System.out.println("How many characters would you like to create? Between 1 and 10 ");
        int numb = Userinput.nextInt();
        for (int i = 0 + 1; i <= numb; i++) {
                System.out.println("Character: " + i);
                character.SetStrength();
                character.SetDexterity();
                character.SetConstitution();
                character.SetIntelligence();
                character.SetWisdom();
                character.SetCharisma();

                System.out.println("Strength: " + character.GetStrength() + ", " + "Dexterity: " + character.GetDexterity() +
                        ", " + "Constitution: " + character.GetConstitution() + ", " + "Intelligence: " + character.GetIntelligence() +
                        ". " + "Wisdom: " + character.GetWisdom() + ", " + "Charisma: " + character.GetCharisma());

                System.out.println("Keep these these stats? 1. Yes, 2. no.");
                int choice = Userinput.nextInt();
                if (choice != 1) {
                    character.SetStrength();
                    character.SetDexterity();
                    character.SetConstitution();
                    character.SetIntelligence();
                    character.SetWisdom();
                    character.SetCharisma();

                    System.out.println("Strength: " + character.GetStrength() + ", " + "Dexterity: " + character.GetDexterity() +
                            ", " + "Constitution: " + character.GetConstitution() + ", " + "Intelligence: " + character.GetIntelligence() +
                            ". " + "Wisdom: " + character.GetWisdom() + ", " + "Charisma: " + character.GetCharisma());
                }

                System.out.println("Please enter your name. ");
                character.SetCharacterName();

                System.out.println("Please choose a race.");
                System.out.println("1. Dragon-born,2 Dwarf, 3. Elf, 4.Gnome, " +
                        "5. Goblin, 6. Half-ling, 7. Half-Elf, 8. Half-Orc, 9. Human, and 10. Tiefling.");
                character.SetCharacterRace();

                System.out.println("Please select a class. ");
                System.out.println("1. Alchemist, 2. Barbarian, 3. Bard, 4. Cleric, 5. Druid, 6. Fighter" +
                        "7. Paladin, 8. Ranger, 9. Rogue, 10. Sorcerer, 11. Witch, 12. Wizard");
                character.SetCharacterClass();

                System.out.println("Please pick a gender. ");
                System.out.println("1. Male or 2. Female ");
                character.SetCharacterGender();

                System.out.println("Choose Alignment. ");
                System.out.println("1. Lawful Good, 2. Neutral Good, 3. Chaotic Good, 4. Lawful Neutral, " +
                        "5. True Neutral, 6. Chaotic Neutral, 7. Lawful Evil, 8. Neutral Evil, 9. Chaotic Evil");
                character.SetCharacterAlignment();

                String[] CharacterArray = new String[6];
                for (int n = 0; n < CharacterArray.length;n++){
                    CharacterArray[0] = "Strength: " + character.GetStrength() + ", " + "Dexterity: " + character.GetDexterity() +
                            ", " + "Constitution: " + character.GetConstitution() + ", " + "Intelligence: " + character.GetIntelligence() +
                            ". " + "Wisdom: " + character.GetWisdom() + ", " + "Charisma: " + character.GetCharisma();
                    CharacterArray[1] = ("Name: " + character.GetName());
                    CharacterArray[2] = ("Race: " + character.GetRace());
                    CharacterArray[3] = ("Class: " + character.GetClass());
                    CharacterArray[4] = ("Gender: " + character.GetGender());
                    CharacterArray[5] = ("Alignment: " + character.GetAlignment());
                    System.out.println(CharacterArray[n]);
                }
        }
        System.out.println("thank you for playing.");
    }
    public static int StatGenerator(){
        Random random = new Random();
        int max = 18, min = 3;
        int number = random.nextInt(max - min + 1);
        return number;
    }
}