import java.util.Scanner;

public class Character {

    Scanner UserInput = new Scanner(System.in);
    private String _CharacterName;
    private String _Race;
    private String _Class;
    private String _Gender;
    private String _Alignment;
    private int _Strength;
    private int _Dexterity;
    private int _Constitution;
    private int _Intelligence;
    private int _Wisdom;
    private int _Charisma;
    public Character(){}

    public String GetName(){
        return this._CharacterName;
    }

    public void SetCharacterName(){
        this._CharacterName = UserInput.next();
    }

    public String GetRace() {
        return _Race;
    }

    public void SetCharacterRace(){
        int _Choice = UserInput.nextInt();
        switch(_Choice) {
            case 1: _Race = "Dragon-born";
                break;
            case 2: _Race = "Dwarf";
                break;
            case 3: _Race = "Elf";
                break;
            case 4: _Race = "Gnome";
                break;
            case 5: _Race = "Goblin";
                break;
            case 6: _Race = "Half-ling";
                break;
            case 7: _Race = "Half-Elf";
                break;
            case 8: _Race = "Half-Orc";
                break;
            case 9: _Race = "Human";
                break;
            case 10: _Race = "Tiefling";
                break;
            default: _Race = "This choice is invalid. ";
        }
    }

    public String GetClass() {
        return _Class;
    }

    public void SetCharacterClass(){
        int _Choice = UserInput.nextInt();
        switch (_Choice) {
            case 1: _Class = "Alchemist";
                break;
            case 2: _Class = "Barbarian";
                break;
            case 3: _Class = "Bard";
                break;
            case 4: _Class = "Cleric";
                break;
            case 5: _Class = "Druid";
                break;
            case 6: _Class = "Fighter";
                break;
            case 7: _Class = "Paladin";
                break;
            case 8: _Class = "Ranger";
                break;
            case 9: _Class = "Rouge";
                break;
            case 10: _Class = "Sorcerer";
                break;
            case 11: _Class = "Witch";
                break;
            case 12: _Class = "Wizard";
                break;
            default: _Class = "This choice is invalid. ";
        }
    }

    public String GetGender() {
        return _Gender;
    }

    public void SetCharacterGender() {
        int _Choice = UserInput.nextInt();
        switch (_Choice){
            case 1: _Gender = "Male";
                break;
            case 2: _Gender = "Female";
                break;
            default: _Gender = "This choice is invalid.";
        }
    }

    public String GetAlignment() {
        return _Alignment;
    }

    public void SetCharacterAlignment() {
        int _Choice = UserInput.nextInt();
        switch (_Choice){
            case 1: _Alignment = "Lawful Good";
                break;
            case 2: _Alignment = "Neutral Good";
                break;
            case 3: _Alignment = "Chaotic Good";
                break;
            case 4: _Alignment = "Lawful Neutral";
                break;
            case 5: _Alignment = "True Neutral";
                break;
            case 6: _Alignment = "Chaotic Neutral";
                break;
            case 7: _Alignment = "Lawful Evil";
                break;
            case 8: _Alignment = "Neutral Evil";
                break;
            case 9: _Alignment = "Chaotic Evil";
                break;
            default: _Alignment = "This choice is invalid. ";
        }
    }

    public int GetStrength() {
        return _Strength;
    }

    public void SetStrength() {
        int _number = Main.StatGenerator();
        this._Strength = _number;
    }

    public int GetDexterity(){
        return _Dexterity;
    }

    public void SetDexterity() {
        int _number = Main.StatGenerator();
        this._Dexterity = _number;
    }
    public int GetConstitution(){
        return _Constitution;
    }

    public void SetConstitution() {
        int _number = Main.StatGenerator();
        this._Constitution = _number;
    }

    public int GetIntelligence() {
        return _Intelligence;
    }

    public void SetIntelligence() {
        int _number = Main.StatGenerator();
        this._Intelligence = _number;
    }

    public int GetWisdom() { return _Wisdom;}

    public void SetWisdom() {
        int _number = Main.StatGenerator();
        this._Wisdom = _number;
    }

    public int GetCharisma() {return _Charisma;}

    public void SetCharisma() {
        int _number = Main.StatGenerator();
        this._Charisma = _number;
    }
}
