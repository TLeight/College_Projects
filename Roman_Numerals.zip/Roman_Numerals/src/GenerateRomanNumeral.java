import java.util.Scanner;
public class GenerateRomanNumeral {
    private int numberOfNumerals;
    private String _output;
    private int _choice;
    public Scanner userInput = new Scanner(System.in);

    GenerateRomanNumeral() {

        numberOfNumerals = 0;
    }

    public int parseNumberOfNumerals(String numeral) {

        return numeral.length();
    }

    public void setNumber() {
        _choice = userInput.nextInt();
        if(_choice <= 9){
            String _numb = String.valueOf(_choice);
           _output = getRomanNumeral(_numb);
        } else if (_choice <= 99) {
            String _numb = String.valueOf(_choice);
            _output = getRomanNumeral(_numb);
        } else if (_choice <= 999) {
            String _numb = String.valueOf(_choice);
            _output = getRomanNumeral(_numb);
        } else if (_choice <= 9999) {
            String _numb = String.valueOf(_choice);
            _output = getRomanNumeral(_numb);
        }
    }

    public String getNumber() {
        return _output;
    }



    public String getRomanNumeral(String decimalNumber) {
        // Create and implement a way for the code to handle if a negative number is entered

        String thousands = "";
        String hundreds = "";
        String tens = "";
        String ones = "";

        numberOfNumerals = parseNumberOfNumerals(decimalNumber);

        if (numberOfNumerals >= 4) {
            // Have to parse out Thousands, then Hundreds, then tens then ones
            thousands = parseThousandsPlace(decimalNumber);
        }
        if (numberOfNumerals >= 3) {
            // Have to parse out hundreds, then tens then ones
            hundreds = parseHundredsPlace(decimalNumber);
        }
        if (numberOfNumerals >= 2) {
            // Have to parse out tens then ones
            tens = parseTensPlace(decimalNumber);
        }
        //Have to parse out ones
        ones = parseOnesPlace(decimalNumber);

        //Assemble final Roman Numeral
        String generatedRomanNumeral = thousands + hundreds + tens + ones;

        return generatedRomanNumeral;
    }

    public String parseOnesPlace(String numeral) {
        char onesPlace;

        // Refactor across all methods (parseHundredsPlace, parseTensPlace, parseOnesPlace) how this is done into a method and properly test it
        if (numberOfNumerals == 4) {
            onesPlace = numeral.charAt(3);
        } else if (numberOfNumerals == 3) {
            onesPlace = numeral.charAt(2);
        } else if (numberOfNumerals == 2) {
            onesPlace = numeral.charAt(1);
        } else {
            onesPlace = numeral.charAt(0);
        }

        if (onesPlace == '1') {
            return "I";
        } else if (onesPlace == '2') {
            return "II";
        } else if (onesPlace == '3') {
            return "III";
        } else if (onesPlace == '4') {
            return "IV";
        } else if (onesPlace == '5') {
            return "V";
        } else if (onesPlace == '6') {
            return "VI";
        } else if (onesPlace == '7') {
            return "VII";
        } else if (onesPlace == '8') {
            return "VIII";
        } else if (onesPlace == '9') {
            return "IX";
        }
        return "";
    }

    public String parseTensPlace(String numeral) {
        char tensPlace ;

        if (numberOfNumerals == 4) {
            tensPlace = numeral.charAt(2);
        }else if (numberOfNumerals == 3) {
            tensPlace = numeral.charAt(1);
        } else {
            tensPlace = numeral.charAt(0);
        }

        if (tensPlace == '1') {
            return "X";
        } else if (tensPlace == '2') {
            return "XX";
        } else if (tensPlace == '3') {
            return "XXX";
        } else if (tensPlace == '4') {
            return "XL";
        } else if (tensPlace == '5') {
            return "L";
        } else if (tensPlace == '6') {
            return "LX";
        } else if (tensPlace == '7') {
            return "LXX";
        } else if (tensPlace == '8') {
            return "LXXX";
        } else if (tensPlace == '9') {
            return "XC";
        }
        return "";
    }

    public String parseHundredsPlace (String numeral) {
        char hundredsPlace;

        if (numberOfNumerals == 4) {
            hundredsPlace = numeral.charAt(1);
        } else {
            hundredsPlace = numeral.charAt(0);
        }

        if (hundredsPlace == '1') {
            return "C";
        } else if (hundredsPlace == '2') {
            return "CC";
        } else if (hundredsPlace == '3') {
            return "CCC";
        } else if (hundredsPlace == '4') {
            return "CD";
        } else if (hundredsPlace == '5') {
            return "D";
        } else if (hundredsPlace == '6') {
            return "DC";
        } else if (hundredsPlace == '7') {
            return "DCC";
        } else if (hundredsPlace == '8') {
            return "DCCC";
        } else if (hundredsPlace == '9') {
            return "DM";
        }
        return "";
    }

    public String parseThousandsPlace (String numeral) {
        // Refactor Method to be More Efficient

        char thousandsPlace = numeral.charAt(0);
        if (thousandsPlace == '1') {
            return "M";
        } else if (thousandsPlace == '2') {
            return "MM";
        } else if (thousandsPlace == '3') {
            return "MMM";
        }
        return "MMMM";
    }
}

