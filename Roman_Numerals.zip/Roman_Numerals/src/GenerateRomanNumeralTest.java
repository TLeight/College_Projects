import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GenerateRomanNumeralTest {

    private GenerateRomanNumeral service;

    @BeforeEach
    void setUp() {
        service = new GenerateRomanNumeral();
    }

    @Test
    void parseNumberOfNumerals_oneCharacterString_shouldReturnOne() {
        int expected = 1;
        int actual = service.parseNumberOfNumerals("1");

        assert(expected == actual);
    }

    @Test
    void parseNumberOfNumerals_twoCharacterString_shouldReturnTwo() {
        int expected = 2;
        int actual = service.parseNumberOfNumerals("10");

        assert(expected == actual);
    }

    @Test
    void parseNumberOfNumerals_threeCharacterString_shouldReturnThree() {
        int expected = 3;
        int actual = service.parseNumberOfNumerals("199");

        assert(expected == actual);
    }

    @Test
    void parseNumberOfNumerals_fourCharacterString_shouldReturnFour() {
        int expected = 4;
        int actual = service.parseNumberOfNumerals("9999");

        assert(expected == actual);
    }

    @Test
    void parseOnesPlace_valueOneEntered_shouldReturnI() {
        String expected = "I";
        String actual = service.parseOnesPlace("1");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueTwoEntered_shouldReturnII() {
        String expected = "II";
        String actual = service.parseOnesPlace("2");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueThreeEntered_shouldReturnIII() {
        String expected = "III";
        String actual = service.parseOnesPlace("3");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueFourEntered_shouldReturnIV() {
        String expected = "IV";
        String actual = service.parseOnesPlace("4");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueFiveEntered_shouldReturnV() {
        String expected = "V";
        String actual = service.parseOnesPlace("5");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueSixEntered_shouldReturnVI() {
        String expected = "VI";
        String actual = service.parseOnesPlace("6");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueSevenEntered_shouldReturnVII() {
        String expected = "VII";
        String actual = service.parseOnesPlace("7");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueEightEntered_shouldReturnVIII() {
        String expected = "VIII";
        String actual = service.parseOnesPlace("8");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueNineEntered_shouldReturnIX() {
        String expected = "IX";
        String actual = service.parseOnesPlace("9");

        assert (expected.equals(actual));
    }

    @Test
    void parseOnesPlace_valueZeroEntered_shouldReturnEmptyString() {
        String expected = "";
        String actual = service.parseOnesPlace("0");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueTenEntered_shouldReturnX() {
        String expected = "X";
        String actual = service.parseTensPlace("10");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueTwentyEntered_shouldReturnXX() {
        String expected = "XX";
        String actual = service.parseTensPlace("20");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueThirtyEntered_shouldReturnXXX() {
        String expected = "XXX";
        String actual = service.parseTensPlace("30");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueFortyEntered_shouldReturnXL() {
        String expected = "XL";
        String actual = service.parseTensPlace("40");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueFiftyEntered_shouldReturnL() {
        String expected = "L";
        String actual = service.parseTensPlace("50");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueSixtyEntered_shouldReturnLX() {
        String expected = "LX";
        String actual = service.parseTensPlace("60");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueSeventyEntered_shouldReturnLXX() {
        String expected = "LXX";
        String actual = service.parseTensPlace("70");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueEightyEntered_shouldReturnLXXX() {
        String expected = "LXXX";
        String actual = service.parseTensPlace("80");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueNinetyEntered_shouldReturnXC() {
        String expected = "XC";
        String actual = service.parseTensPlace("90");

        assert (expected.equals(actual));
    }

    @Test
    void parseTensPlace_valueZeroEntered_shouldReturnEmptyString() {
        String expected = "";
        String actual = service.parseTensPlace("0");

        assert (expected.equals(actual));
    }

    @Test
    void parseHundredsPlace_valueOneHundredEntered_shouldReturnC() {
        String expected = "C";
        String actual = service.parseHundredsPlace("100");

        assert (expected.equals(actual));
    }

    // Write all remaining unit tests for Hundreds Place

    @Test
    void parseThousandsPlace_valueOneThousandEntered_shouldReturnM() {
        String expected = "M";
        String actual = service.parseThousandsPlace("1000");

        assert (expected.equals(actual));
    }

    // Write all remaining unit tests for Thousands Place

    @Test
    void getRomanNumeral_valueOneEntered_shouldReturnI() {
        String expected = "I";
        String actual = service.getRomanNumeral("1");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueElevenEntered_shouldReturnXI() {
        String expected = "XI";
        String actual = service.getRomanNumeral("11");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueTwentyFiveEntered_shouldReturnXXV() {
        String expected = "XXV";
        String actual = service.getRomanNumeral("25");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueFortyEntered_shouldReturnXL() {
        String expected = "XL";
        String actual = service.getRomanNumeral("40");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueNinetyNineEntered_shouldReturnXCIX() {
        String expected = "XCIX";
        String actual = service.getRomanNumeral("99");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueTwoHundredThirtyFiveEntered_shouldReturnCCXXXV() {
        String expected = "CCXXXV";
        String actual = service.getRomanNumeral("235");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueFiveHundredEntered_shouldReturnD() {
        String expected = "D";
        String actual = service.getRomanNumeral("500");

        assert (expected.equals(actual));
    }

    @Test
    void getRomanNumeral_valueTwoThousandThreeHundredSeventySixEntered_shouldReturnMMCCCLXXVI() {
        String expected = "MMCCCLXXVI";
        String actual = service.getRomanNumeral("2376");

        assert (expected.equals(actual));
    }
}
