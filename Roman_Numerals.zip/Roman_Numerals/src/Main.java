public class Main {
    public static void main(String[] args) {
        // Create a way to get a number from the user, run the program, and output the result

        GenerateRomanNumeral RomanNumeral = new GenerateRomanNumeral();

        System.out.println("Enter a number");
        RomanNumeral.setNumber();

        System.out.println(RomanNumeral.getNumber());
    }
}
