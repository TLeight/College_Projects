/*
    Tyler Leight

    1-11-2023

    CIS-171

    instructor: Richard Morgan

    Program asks for users first name
    program will then ask for the users Age.
*/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner Userinput = new Scanner(System.in);

        System.out.printf("Please enter your name: ");

        String Name = Userinput.nextLine();

        System.out.printf("Please enter your age: ");
        int Age = Userinput.nextInt();

        System.out.println(("Username" + " " + Name));
        
        System.out.println(("User age" + " " + Age));

    }
}

