import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        System.out.println("Welcome to HFC Credit Union. Please select account to access.");
        Scanner Userinput = new Scanner(System.in);
        Account account = new Account();
        System.out.println("1. Tony Stark");
        System.out.println("2. Bruce Wayne");
        account.SetChoice();
        account.SetName();
        account.SetAccountNumber();
        account.SetSavingsBalance();
        account.SetCheckingBalance();
        account.SetLoanBalance();
        double dblbalance = account.GetSavingsBalance();
        double dbltrans;
        double dblchecking = account.GetCheckingBalance();
        double dblloanbalance = account.GetLoanBalance();
        double newdblbalance;
        double newdblchecking;
        double dblloanpayment;
        double newdblloanpayment;
        if (account.GetChoice() == 1) {
            while (account.GetChoice() == 1) {
                System.out.println("1. Check balance");
                System.out.println("2. Deposit");
                System.out.println("3. Withdraw");
                System.out.println("4. Transfer");
                System.out.println("5. Pay");
                System.out.println("6. Exit");
                account.SetChoice();
                if (account.GetChoice() == 1) {
                    System.out.println("Name: " + account.GetName());
                    System.out.println("Account Number: " + account.GetAccountNumber());
                    System.out.println("Savings Balance: " + account.GetSavingsBalance());
                    System.out.println("Checking Balance: " + account.GetCheckingBalance());
                    System.out.println("Loan Balance: " + account.GetLoanBalance());
                } else if (account.GetChoice() == 2) {
                    System.out.println("How much money would you like to Deposit. ");
                    double dbladd = Userinput.nextDouble();
                    newdblbalance = dblbalance += dbladd;
                    System.out.println("money Deposited " + dbladd);
                    System.out.println("New Balance " + newdblbalance);
                } else if (account.GetChoice() == 3) {
                    System.out.println("How much money would you like to WithDraw. ");
                    double dblsub = Userinput.nextDouble();
                    newdblbalance = dblbalance - dblsub;
                    System.out.println("money WithDrawn " + dblsub);
                    System.out.println("New Balance " + newdblbalance);
                } else if (account.GetChoice() == 4) {
                    System.out.println("How much money to transfer to checking");
                    dbltrans = Userinput.nextDouble();
                    newdblbalance =  dblbalance - dbltrans;
                    newdblchecking = dblchecking + dbltrans;
                    System.out.println("balance " + newdblbalance );
                    System.out.println("checking " + newdblchecking);
                } else if (account.GetChoice() == 5) {
                    System.out.println("Please enter the amount you would like to pay. ");
                    dblloanpayment = Userinput.nextDouble();
                    newdblloanpayment = dblloanbalance - dblloanpayment;
                    System.out.println("Loan balance " + newdblloanpayment);
                }else if (account.GetChoice() == 6){
                    return;
                }else {
                    if ((account.GetChoice() >= 7)) {
                        System.out.println("Please choose a number between 1 and 7.");
                        return;
                    }
                }
            }
        } else if (account.GetChoice() == 2) {
            while (account.GetChoice() == 2) {
                System.out.println("1. Check balance");
                System.out.println("2. Deposit");
                System.out.println("3. Withdraw");
                System.out.println("4. Transfer");
                System.out.println("5. Pay");
                System.out.println("6. Exit");
                account.SetChoice();
                if (account.GetChoice() == 1) {
                    System.out.println("Name: " + account.GetName());
                    System.out.println("Account Number: " + account.GetAccountNumber());
                    System.out.println("Savings Balance: " + account.GetSavingsBalance());
                    System.out.println("Checking Balance: " + account.GetCheckingBalance());
                    System.out.println("Loan Balance: " + account.GetLoanBalance());
                } else if (account.GetChoice() == 2) {
                    System.out.println("How much money would you like to Deposit. ");
                    double dbladd = Userinput.nextDouble();
                    newdblbalance = dblbalance += dbladd;
                    System.out.println("money Deposited " + dbladd);
                    System.out.println("New Balance " + newdblbalance);
                } else if (account.GetChoice() == 3) {
                    System.out.println("How much money would you like to WithDraw. ");
                    double dblsub = Userinput.nextDouble();
                    newdblbalance = dblbalance - dblsub;
                    System.out.println("money WithDrawn " + dblsub);
                    System.out.println("New Balance " + newdblbalance);
                } else if (account.GetChoice() == 4) {
                    System.out.println("How much money to transfer to checking");
                    dbltrans = Userinput.nextDouble();
                    newdblbalance =  dblbalance - dbltrans;
                    newdblchecking = dblchecking + dbltrans;
                    System.out.println("balance " + newdblbalance );
                    System.out.println("checking " + newdblchecking);
                } else if (account.GetChoice() == 5) {
                    System.out.println("Please enter the amount you would like to pay. ");
                    dblloanpayment = Userinput.nextDouble();
                    newdblloanpayment = dblloanbalance - dblloanpayment;
                    System.out.println("Loan balance " + newdblloanpayment);
                }else if (account.GetChoice() == 6){
                    return;
                }else {
                    if ((account.GetChoice() >= 7)) {
                        System.out.println("Please choose a number between 1 and 7.");
                        return;
                    }
                }
            }
        }else {
            if ((account.GetChoice() >= 3)) {
                System.out.println("Please press 1 or 2. .");
            }
        }
    }
}