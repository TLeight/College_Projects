import java.util.Scanner;

public class Account {
        Scanner UserInput = new Scanner(System.in);

        private int _choice;
        private String _name;
        private String _accountnumber;
        private double _savingsbalance;
        private double _checkingbalance;
        private double _loanbalance;

        public Account() {}

        public int GetChoice(){
            return _choice;
        }

        public void SetChoice(){
            this._choice = UserInput.nextInt();

        }

        public String GetName() {
            return _name;
        }

        public void SetName(){
            if (_choice == 1)
            {
                this._name = "Tony Stark";
            }else if (_choice == 2) {
                this._name = "Bruce Wayne";
            }
        }
       public String GetAccountNumber(){
            return _accountnumber;
       }

    public void SetAccountNumber() {
            if (_choice == 1) {
                this._accountnumber = "123456789";
            }else if (_choice == 2) {
                this._accountnumber = "987654321";
            }
    }

    public double GetSavingsBalance() {
        return _savingsbalance;
    }

    public void SetSavingsBalance() {
        if (_choice == 1) {
            this._savingsbalance = 4500.00d;
        }else if (_choice == 2) {
            this._savingsbalance = 200.00d;
        }
    }

    public double GetCheckingBalance() {
        return _checkingbalance;
    }

    public void SetCheckingBalance() {
            if (_choice == 1) {
                this._checkingbalance = 700.00d;
        }else if (_choice == 2) {
                this._checkingbalance = 800.00;
            }
    }

    public double GetLoanBalance() {
        return _loanbalance;
    }

    public void SetLoanBalance() {
            if (_choice == 1) {
                this._loanbalance = 350.00d;
            }else if (_choice == 2) {
                this._loanbalance = 160.00;
            }
    }


}
