﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Student_Info
{
    public class Students
    {
        public Students()
        {
            strID = "";
            strFirstName = "";
            strLastName = "";
            strStreetAdress = "";
            strCity = "";
            strState = "";
            strZipcode = "";
        }
        public string strID { get; set; }

        public string strFirstName { get; set; }

        public string strLastName { get; set; }

        public string strStreetAdress { get; set; }

        public string strCity { get; set; }

        public string strState { get; set; }

        public string strZipcode { get; set; }

    }
}
