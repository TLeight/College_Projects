﻿using Student_Info;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
namespace Student_Addresses
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //Set focus to the first input control
            txtStudentID.Focus();
        }

        const string StudentList = "StudentList.Text"; 
        List<Students> lstStudents = new List<Students>();

        private void btnAddStudent_Click(object sender, RoutedEventArgs e)
        {
            string strErrorMessage;

            strErrorMessage = UserValidation.IsPresent(txtStudentID.Text, "Student ID");
            strErrorMessage += UserValidation.IsValidID(txtStudentID.Text);
            strErrorMessage += UserValidation.IsPresent(txtFirstName.Text, "First Name");
            strErrorMessage += UserValidation.IsPresent(txtLastName.Text, "Last Name");
            strErrorMessage += UserValidation.IsPresent(txtAddress.Text, "Street Address");
            strErrorMessage += UserValidation.IsPresent(txtCity.Text, "City");
            strErrorMessage += UserValidation.IsPresent(txtState.Text, "State");
            strErrorMessage += UserValidation.IsPresent(txtZipcode.Text, "Zip Code");

            if(strErrorMessage != "")
            {
                MessageBox.Show(strErrorMessage);
                return;
            }
              
            Students StudentInfo = new Students();

            StudentInfo.strID = txtStudentID.Text.Trim();

            StudentInfo.strFirstName = txtFirstName.Text.Trim();

            StudentInfo.strLastName = txtLastName.Text.Trim();

            StudentInfo.strStreetAdress = txtAddress.Text.Trim();

            StudentInfo.strCity = txtCity.Text.Trim();

            StudentInfo.strState = txtState.Text.Trim();

            StudentInfo.strZipcode = txtZipcode.Text.Trim();

            lstStudents.Add(StudentInfo);

        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                StreamWriter outputFile;

                outputFile = File.CreateText(StudentList);

                string strOutput;

                foreach (Students stu in lstStudents)
                {
                    strOutput = stu.strID + "|" + stu.strFirstName + "|" + stu.strLastName + "|" + stu.strStreetAdress + 
                        "|" + stu.strCity + "|" + stu.strState + "|" + stu.strZipcode;

                    outputFile.WriteLine(strOutput);
                }
                outputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Disk problem");
            }

            
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
